//export const BASE_URL = 'https://allupipay.in';
export const BASE_URL = 'https://allupipay.in/publicsewa/';

export const PROFILE_IMAGE_URL = 'https://allupipay.in/publicsewa/images/';

export const DOMAIN_URL = 'https://allupipay.in/';


